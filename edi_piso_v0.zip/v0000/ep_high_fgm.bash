################################################################
 export GDC_RDDA_ROOT="$5"
 export GDC_RDDA_ROOT2="${10}"
 export EDI_PISO_PRODUCTION_DATE="$1" 
 export EDI_PISO_SC_NUMBER="$2" 
 export EDI_PISO_FGM_OUT="$9"  

 begt="$3"
 endt="$4"

#####################  Don't change anything below this line ###
 FGMROOT="$6"
 export FGMPATH="$FGMROOT/cal/"
 export SATTPATH="$7"
 exepath="$FGMROOT/bin//"
 inp="$GDC_RDDA_ROOT/rdda/"
 inp1="$GDC_RDDA_ROOT2/rdda_bck/"
 date=`echo $EDI_PISO_PRODUCTION_DATE | cut -c3-8`
 sc="$EDI_PISO_SC_NUMBER"
 infiles=`find $inp -name *$date*fn*$sc -a ! -size 0 -o -name *$date*fb*$sc -a ! -size 0`
 if [ "$infiles" = "" ]; then
 infiles=`find $inp1 -name *$date*fn*$sc -a ! -size 0 -o -name *$date*fb*$sc -a ! -size 0`
 fi
 if [ "$infiles" = "" ]; then 
    echo FGM data for $EDI_PISO_PRODUCTION_DATE not found;
 else
 $exepath/ddsmrg $infiles|$exepath/ddscut -b $begt -e $endt|
 $exepath/fgmtel | $exepath/fgmcal -i|
 $exepath/fgmhrt -s scs | $exepath/fgmvec -t1 -r -o $8
 \rm cal.log
 fi
################################################################    

