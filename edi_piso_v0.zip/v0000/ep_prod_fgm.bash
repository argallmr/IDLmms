
DO NOT USE THIS SCRIPT...USE ep_spin_fgm.bash INSTEAD.



################################################################
EDI_PISO_PRODUCTION_DATE="$1" 
EDI_PISO_SC_NUMBER="$2"
GDC_RDDA_ROOT="$3"
SPINFGM_OUT="$4"
SATTPATH="$5"
FGMROOT="$6"

echo 'ep_prod_fgm.bash: '
echo $EDI_PISO_PRODUCTION_DATE
echo $EDI_PISO_SC_NUMBER
echo $GDC_RDDA_ROOT
echo $SPINFGM_OUT
echo $SATTPATH
echo $FGMROOT

#####################  Don't change anything below this line ###
 export FGMPATH="$FGMROOT/cal/"
 exepath="$FGMROOT/bin/"
 date=`echo $EDI_PISO_PRODUCTION_DATE | cut -c3-8`
 sc="$EDI_PISO_SC_NUMBER"
 FGM_OUT="$SPINFGM_OUT"

 inp="$GDC_RDDA_ROOT/"
 infiles=`find $inp -name *$date*fn*$sc -a ! -size 0 -o -name *$date*fb*$sc -a ! -size 0`
 if [ "$infiles" = "" ]; then
    inp="$GDC_RDDA_ROOT/rdda_bck/"
    infiles=`find $inp -name *$date*fn*$sc -a ! -size 0 -o -name *$date*fb*$sc -a ! -size 0`
    if [ "$infiles" = "" ]; then
       echo FGM data for $EDI_PISO_PRODUCTION_DATE not found;
    else
       attf=`find $inp -name *$date*ga.1?$sc`
       eclf=`find $inp -name *$date*ta.1?$sc`
       $exepath/fgmpp $infiles -e $eclf -i -o $FGM_OUT
       \rm tmp_att; \rm cal.log
    fi
 else
    attf=`find $inp -name *$date*ga.1?$sc`
    eclf=`find $inp -name *$date*ta.1?$sc`
    $exepath/fgmpp $infiles -e $eclf -i -o $FGM_OUT
    \rm tmp_att; \rm cal.log
 fi
################################################################    


